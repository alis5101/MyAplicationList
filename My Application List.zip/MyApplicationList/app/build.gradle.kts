package com.example.myapplicationlist

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.example.myapplicationlist.ui.theme.MyApplicationListTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationListTheme {
                DogListApp()
            }
        }
    }
}

@Composable
fun DogListApp() {
    var dogName by remember { mutableStateOf("") }
    var dogs by remember { mutableStateListOf<String>() }
    var favorites by remember { mutableStateListOf<String>() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(text = "🐶: ${dogs.size}   ❤️: ${favorites.size}", style = MaterialTheme.typography.h6)

        Spacer(modifier = Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            TextField(
                value = dogName,
                onValueChange = { dogName = it },
                placeholder = { Text("Wpisz imię pieska") },
                modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    if (dogName.isNotBlank()) {
                        dogs.add(dogName)
                        dogName = ""
                    }
                })
            )

            Spacer(modifier = Modifier.width(8.dp))

            Button(onClick = {
                if (dogName.isNotBlank()) {
                    dogs.add(dogName)
                    dogName = ""
                }
            }) {
                Text("Dodaj")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Column {
            dogs.forEach { dog ->
                DogRow(
                    name = dog,
                    isFavorite = favorites.contains(dog),
                    onFavoriteClick = {
                        if (favorites.contains(dog)) favorites.remove(dog) else favorites.add(dog)
                    },
                    onDeleteClick = { dogs.remove(dog); favorites.remove(dog) }
                )
            }
        }
    }
}

@Composable
fun DogRow(name: String, isFavorite: Boolean, onFavoriteClick: () -> Unit, onDeleteClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = name, modifier = Modifier.weight(1f), style = MaterialTheme.typography.body1)

        IconButton(onClick = onFavoriteClick) {
            Icon(
                imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = null
            )
        }

        IconButton(onClick = onDeleteClick) {
            Icon(imageVector = Icons.Default.Delete, contentDescription = null)
        }
    }
}
